#include "cocos2d.h"
#include "XProperties.h"

class AGameObject : public cocos2d::Node
{
public:
    virtual void update() = 0;

};
