#pragma once

#define MIN_LABEL_SIZE 14