#pragma once

#include "../platform/ZYMacros.h"

USING_NS_CC;

NS_ZY_BEGIN

NS_ZY_END