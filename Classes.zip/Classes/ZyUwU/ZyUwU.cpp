#include "ZyUwU.h"

NS_ZY_BEGIN
static const char* zyuwuVersion()
{
    return "zyuwu-1.0";
}
NS_ZY_END