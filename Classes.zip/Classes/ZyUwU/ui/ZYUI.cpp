#include "ZYUI.h"

NS_ZY_BEGIN

///] Floating Notify

ZYFloatingNotify* ZYFloatingNotify::create(const std::string& title, Point& targetPos)
{

}

NS_ZY_END