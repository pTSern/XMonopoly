#include "GameEffect.h"

//// Constructor

GameEffect::GameEffect()
{

}

//// Public

bool GameEffect::init()
{
    return true;
}

void GameEffect::log()
{

}

std::string GameEffect::toString(int nTab)
{
    std::string ts;
    return ts;
}

//Virtual

void GameEffect::update(float dt)
{

}