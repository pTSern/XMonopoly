#include "Mage.h"

////Constructor

Mage::Mage() : Champion()
{

}

////Public

//Virtual

bool Mage::init()
{


    return true;
}

void Mage::log()
{

}

std::string Mage::toString(int nTab)
{
    std::string ts;
    return ts;
}

