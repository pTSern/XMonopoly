#pragma once

#include "../Champion.h"

USING_NS_ALL;


BEGIN_CREATE_REFCLASS(Mage, Champion)

public:



END_CREATE_REFCLASS