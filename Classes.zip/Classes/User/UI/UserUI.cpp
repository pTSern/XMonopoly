#include "UserUI.h"

//Constructor

UserUI::UserUI()
{

}

//Public

bool UserUI::init()
{
    return true;
}

void UserUI::log()
{

}

std::string UserUI::toString(int nTab)
{
    std::string tab = ZY_SP_TAB(nTab);
    std::string ts;
    return ts;
}



