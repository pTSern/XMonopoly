#include "IngameUI.h"

IngameUI::IngameUI()
{

}

bool IngameUI::init()
{
    return true;
}

void IngameUI::log()
{

}

std::string IngameUI::toString(int nTab)
{
    std::string ts;
    std::string tab = ZY_SP_TAB(nTab);

    return ts;
}