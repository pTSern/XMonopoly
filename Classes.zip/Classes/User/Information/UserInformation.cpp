#include "UserInformation.h"

//Constructor

UserInformation::UserInformation()
{

}

//Public

bool UserInformation::init()
{
    return true;
}

std::string UserInformation::toString(int nTab)
{
    std::string ts;
    std::string tab = ZY_SP_TAB(nTab);
    return ts;
}

void UserInformation::log()
{

}

