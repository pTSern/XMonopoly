#include "User.h"

///] Constructor

User::User()
{

}

///] Virtual

bool User::init()
{
    return true;
}

void User::log()
{

}

std::string User::toString(int nTab)
{
    std::string ts;
    std::string tab = ZY_SP_TAB(nTab);
    return ts;
}

void User::loadEconomy()
{
}

void User::loadAudio()
{

}

void User::loadGameData()
{

}

void User::loadInformation()
{

}

void User::loadIngameUI()
{

}

void User::loadUI()
{

}
