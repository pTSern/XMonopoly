#pragma once

#include "ZyUwU/ZyUwU.h"

USING_NS_ALL;

class LoginScene : Layer
{
    static Scene* createScene();

    virtual bool init();

    ZY_CREATE_FUNC(LoginScene);
};

