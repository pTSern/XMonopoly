#include "SelectHelper.h"

Selector::Selector()
{

}

bool Selector::init()
{
    return true;
}

void Selector::log()
{

}

std::string Selector::toString(int nTab)
{
    std::string ts;
    return ts;
}

void Selector::glowingTarget(float radius)
{

}

void selectTarget(std::string ts)
{

}
