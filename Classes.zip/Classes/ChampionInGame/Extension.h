#pragma once

enum class ChampionAction
{
    IDLE,
    ATTACK,
    GET_HIT,
    MOVE

};