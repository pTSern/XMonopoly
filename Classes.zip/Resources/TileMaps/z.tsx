<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="z" tilewidth="32" tileheight="32" tilecount="100" columns="10">
 <image source="z.png" width="320" height="320"/>
</tileset>
