<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Confetti (16x16)" tilewidth="16" tileheight="16" tilecount="6" columns="6">
 <image source="../Zip/Free/Other/Confetti (16x16).png" width="96" height="16"/>
 <tile id="3">
  <properties>
   <property name="collision" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
